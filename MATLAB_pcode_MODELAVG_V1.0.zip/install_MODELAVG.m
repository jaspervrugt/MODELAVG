%% ------------------------------------------------------------------------------------------- %%
%%                                                                                             %%
%%  MM       MM   OOOOOOO   DDDDDDDD   EEEEEEEE  LL            AAA      VV       VV  GGGGGGGG  %%
%%  MMM      MM  OOOOOOOOO  DDDDDDDDD  EEEEEEEE  LL           AA AA     VV       VV  GG    GG  %%
%%  MMMM   MMMM  OO     OO  DD     DD  EE        LL           AA AA      VV     VV   GG    GG  %%
%%  MM MM MM MM  OO     OO  DD     DD  EEEEE     LL          AA   AA     VV     VV   GGGGGGGG  %%
%%  MM  MMM  MM  OO     OO  DD     DD  EEEEE     LL         AAAAAAAAA     VV   VV    GGGGGGGG  %%
%%  MM       MM  OO     OO  DD     DD  EE        LL         AA     AA      VV VV           GG  %%
%%  MM       MM  OOOOOOOOO  DDDDDDDDD  EEEEEEEE  LLLLLLLL  AA       AA     VV VV          GGG  %%
%%  MM       MM   OOOOOOO   DDDDDDDD   EEEEEEEE  LLLLLLLL  AA       AA      VVV      GGGGGGGG  %%
%%                                                                                             %%
%% ------------------------------------------------------------------------------------------- %%

%% -------------------------- The MODELAVG toolbox in MATLAB  -------------------------------- %%
%%                                                                                             %%
%% Multi-model averaging is widely used in various scientific and engineering disciplines to   %%
%% post-process forecast ensembles and/or quantify conceptual model uncertainty. This MATLAB   %%
%% toolbox, called MODELAVG, implements a suite of different model averaging techniques,       %%
%% including (amongst others) equal weights averaging (EWA), Bates-Granger model averaging     %%
%% (BGA), Bayesian model averaging (BMA), Mallows model averaging (MMA), and                   %%
%% Granger-Ramanathan averaging (GRA). For BMA the user can select among different options for %%
%% the conditional forecast distribution of each individual member of the ensemble. Options    %%
%% include a normal distribution with homoscedastic and heteroscedastic varaiance, a gamma     %%
%% distribution with constant or heteroscedastic variance, and a generalized normal            %%
%% distribution with homoscedastic or non-constant variance. The toolbox returns the           %%
%% optimal values posterior distribution of the weights and related parameters of each model   %%
%% averaging method, along with graphical output of the results. For MMA and BMA the user has  %%
%% access to the entire posterior distribution of the weights and/or variances derived from    %%
%% MCMC simulation with the DREAM algorithm. Three case studies involving forecast ensembles   %%
%% of hydrologic and meteorologic models are used to illustrate the capabilities and           %%
%% functionalities of the MODELAVG toolbox.                                                    %%
%% ------------------------------------------------------------------------------------------- %%

%% ------------------------------------------------------------------------------------------- %%
%%                                                                                             %%
%% SYNOPSIS: [x] = MODELAVG(method,D,Y)                                                        %%
%%           [x,output] = MODELAVG(method,D,Y,options)                                         %%
%%                                                                                             %%
%% Input:    method      string with name of model averaging method to use                     %%
%%           D           n x K matrix with ensemble forecasts                                  %%
%%           Y           n x 1 vector of training data set                                     %%
%%           options     optional structure required for IACA, BICA, MMA and MMA-S             %%
%%                                                                                             %%
%% Output:   x           1 x K vector with weights ( and/or variances if BMA is used )         %%
%%           output      structure with results of MODELAVG                                    %%
%%                                                                                             %%
%% ------------------------------------------------------------------------------------------- %%

%% ------------------------------------------------------------------------------------------- %%
%%                                                                                             %%
%% This algorithm has been described in:                                                       %%
%%   Vrugt, J.A. (2015), MODELAVG: A MATLAB toolbox for postprocessing of model ensembles,     %%
%%       Manual, p. 1-45, 2016.                                                                %%
%%                                                                                             %%
%% For more information please read:                                                           %%
%%   Vrugt, J.A. (2016), Markov chain Monte Carlo simulation using the DREAM software package: %%
%%       Theory, concepts, and MATLAB implementation, Environmental Modeling and Software, 75, %%
%%       273-316, doi:10.1016/j.envsoft.2015.08.013.                                           %%
%%   Diks, C.G.H (2010), and J.A. Vrugt (2010), Comparison of point forecast accuracy of model %%
%%       averaging methods in hydrologic applications, Stochastic Environmental Research and   %%
%%       Risk Assessment, 24(6), 809-820, doi:10.1007/s00477-010-0378-z.                       %%
%%   Vrugt, J.A., C.G.H. Diks, and M.P. Clark (2008), Ensemble Bayesian model averaging using  %%
%%       Markov beta Monte Carlo sampling, Environmental Fluid Mechanics, 8(5-6), 579-595,     %%
%%       doi:10.1007/s10652-008-9106-3.                                                        %%
%%   Vrugt, J.A., and B.A. Robinson (2007), Treatment of uncertainty using ensemble methods:   %%
%%       Comparison of sequential data assimilation and Bayesian model averaging, Water        %%
%%       Resources Research, 43, W01411, doi:10.1029/2005WR004838.                             %%
%%                                                                                             %%
%% ------------------------------------------------------------------------------------------- %%
 
%% ------------------------------------------------------------------------------------------- %%
%%                                                                                             %%
%% MODELAVG code developed by Jasper A. Vrugt, University of California Irvine: jasper@uci.edu %%
%%                                                                                             %%
%% Version 1.0:   March 2015                                                                   %%
%% Version 1.1:   February 2016                                                                %%
%%                                                                                             %%
%% ------------------------------------------------------------------------------------------- %%

%% Check:  http://faculty.sites.uci.edu/jasper
%% Papers: http://faculty.sites.uci.edu/jasper/publications/
%% Google Scholar: https://scholar.google.com/citations?user=zkNXecUAAAAJ&hl=nl

% Different test examples
% example 1: Rainfall runoff transformation: Ensemble of calibrated watershed models
% example 2: 48-forecasts of sea surface temperature
% example 3: 48-forecasts of sea surface pressure

% Go to main DREAM directory 
addpath(pwd,[pwd '/postprocessing'],[pwd '/miscellaneous']);
% Now go to example directory; say example_1
cd example_1
% Now execute this example by typing in command prompt: "example_1" 