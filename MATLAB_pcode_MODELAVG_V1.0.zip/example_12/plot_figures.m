%% This script plots the results of example_12.m script

close all hidden;
which_fig = 2;

ID = [ 6 7 8 9 10 ]; nID = numel(ID);
fig_label = {'(a)','(b)','(c)','(d)','(e)','(f)'};
blue_color = [0 102 255]/255; red_color = [255 0 0]/255;
green_color = [51 153 51]/255; yellow_color = [255 192 0]/255;
orange_color = [122 92 113]/255; cyan_color = [0,255,255]/255;
fontsize_ax = 16; measdata_size = 3.5; Ymax = 12; YmaxSR = 8;
t_id = 2600:2900; nt = numel(t_id);
% Figure extents over entire page
switch which_fig
    case -2 % Plot scatter plot of scoring rules and log-likelihood
        measdata_size = 8;
        QSp = Table_9(1,:); LSp = Table_9(2,:); logL = Table_9(10,:);
        figure('unit','inches','PaperOrientation','portrait','position',[0.1 0.3 13.5 6.5]);
        ax1 = axes('units','inches'); axpos = [ 1.2 , 1 , 5 , 5 ]; set(ax1,'position',axpos);
        % Now add data
        plot(ax1,logL,QSp,'bs','markerfacecolor','w','linewidth',2,'markersize',measdata_size);
        % Adjust figure settings
        set(ax1,'tickdir','out','XMinorTick','on','YMinorTick','on','TickLength',[0.012 0.024],'box','off');
        set(ax1,'fontsize',fontsize_ax,'box','on');
        set(ax1,'box','off');
        axis(ax1,[-3000 500 0.8 4.0]);
        set(ax1,'xtick',-3000:1000:0,'ytick',1.0:1.0:4.0);
        ax2 = axes('units','inches'); axpos = [ 8.0 , 1 , 5 , 5 ]; set(ax2,'position',axpos);
        % Now add data
        plot(ax2,logL,LSp,'bs','markerfacecolor','w','linewidth',2,'markersize',measdata_size);
        % Adjust figure settings
        set(ax2,'tickdir','out','XMinorTick','on','YMinorTick','on','TickLength',[0.012 0.024],'box','off');
        set(ax2,'fontsize',fontsize_ax,'box','on');
        set(ax2,'xtick',-3000:1000:0,'ytick',-1.4:0.4:0.2);
        axis(ax2,[-3000 500 -1.5 0.2]);
        ax2.YAxis.MinorTickValues = [-1.6 -1.5 -1.3 -1.2 -1.1 -0.9 -0.8 -0.7 -0.5 -0.4 -0.3 -0.1 0 0.1];
        set(ax2,'box','off');
        set(gcf,'color','w');
        % print correlation Table of log-likelihood
        logL = Table_9(10,:);
        for u = 1:size(Table_9,1)
            R = corrcoef(logL,Table_9(u,:)); r(1,u) = R(1,2);
        end
        % Now print Table of Latex paper
        str = [];
        for u = 1:numel(r)
            if r(1,u) > 0
                str{u} = strcat('\hphantom{-}$',num2str(r(1,u),'%6.3f'),'$');
            else
                str{u} = strcat('-$',num2str(abs(r(1,u)),'%6.3f'),'$');
            end
        end
        fprintf('logL & %s & %s & %s & %s & %s & %s & %s & %s & %s & %s & %s & %s \\\\',...
            str{1},str{2},str{3},str{4},str{5}, ...
            str{6},str{7},str{8},str{9},str{11},str{12},str{13});
        fprintf('\n');
        %                ax1.YAxis.MinorTickValues = [-1 1 3 5 7 9 11 13 15 17 19 ];
    case -1 % Only the BMA ensemble - for supporting information
        blue_color = [0 102 255]/255;
        green_color = [51 153 51]/255; yellow_color = [246 252 4]/255;
        orange_color = [252 134 4]/255; cyan_color = [0,240,251]/255;
        purple_color = [141,37,219]/255; magenta_color = [240 16 208]/255;
        gray_color = [145 128 111]/255; rose_color = [235 21 210]/255;
        colors = [blue_color ; green_color ; yellow_color ; ...
            orange_color ; cyan_color ; purple_color ; ...
            rose_color ; gray_color ]; colors = flipud(colors);
        figure('unit','inches','PaperOrientation','portrait','position',[0.1 0.3 19 8]);
        t_id = 1:400; nt = numel(t_id);
        y_min = -1; y_max = 20;
        measdata_size = 7;
        ax1 = axes('units','inches'); axpos = [ 1.2 , 0.6 , 17 , 7 ]; set(ax1,'position',axpos);
        for i = 1:K
            plot(ax1,t_id,D(t_id,i),'color',colors(i,1:3),'linewidth',2);
            if i == 1, hold on; end
            % add legend
            xloc1 = t_id(1) + 0.02*max(t_id); xloc2 = t_id(1) + 0.05*max(t_id);
            y_loc = y_min + (0.95 - 0.06*(i-1)) * (y_max-y_min);
            line(ax1,[xloc1 xloc2],[y_loc y_loc],'color',colors(i,1:3),'linewidth',3);
        end
        % Now add data
        plot(ax1,t_id,Y(t_id),'ro','markerfacecolor','w','linewidth',2,'markersize',measdata_size);
        % Adjust figure settings
        set(ax1,'tickdir','out','XMinorTick','on','YMinorTick','on','TickLength',[0.012 0.024],'box','off');
        set(ax1,'fontsize',fontsize_ax,'box','on');
        ax1.YAxis.MinorTickValues = [-1 1 3 5 7 9 11 13 15 17 19 ];
        % Adjust axis
        axis([t_id(1) t_id(end) y_min y_max]);
    case 0
        figure('unit','inches','PaperOrientation','portrait','position',[0.1 0.3 12 10.5]);
        y_min = [ -1/2*ones(1,nID) -YmaxSR ]; y_max = [ Ymax*ones(1,nID) YmaxSR ];
        cyan_color = [0,255,255]/255;
        for i = 1:nID
            zz = ID(i);
            ax1 = axes('units','inches'); axpos = [ 1.2 , 8.9 - (i-1)*1.6 , 10 , 1.5 ]; set(ax1,'position',axpos);
            % Now we add 95% BMA uncertainty
            Fill_Ranges(t_id,predQ(t_id,1,zz),predQ(t_id,6,zz),[0.9 0.9 0.9]); hold on;
            % Now we add 90% BMA uncertainty
            Fill_Ranges(t_id,predQ(t_id,2,zz),predQ(t_id,5,zz),[0.7 0.7 0.7]);
            % Now we add 50% BMA uncertainty
            Fill_Ranges(t_id,predQ(t_id,3,zz),predQ(t_id,4,zz),[0.4 0.4 0.4]);
            % Now add data
            plot(ax1,t_id,Y(t_id),'ro','markerfacecolor','w','linewidth',1,'markersize',measdata_size);
            % And mean of BMA mixture
            plot(ax1,t_id,Mu_mix(t_id,zz),'k','linewidth',1.25);
            % Adjust axis
            axis([t_id(1) t_id(end) y_min(i) y_max(i)]);
            % Adjust figure settings
            set(ax1,'tickdir','out','XMinorTick','on','YMinorTick','on','TickLength',[0.012 0.024],'box','off');
            if i <= nID
                set(ax1,'xticklabel',[],'xtick',[]);
            end
            % set ylabel
            %ylabel(ax1,'${\rm Discharge,\;[mm/d]}$','Interpreter','latex','fontsize',20);
            set(ax1,'fontsize',fontsize_ax,'box','on');
            % Add figure number (label)
            x_loc = t_id(1) + 0.005*(t_id(nt)-t_id(1)); y_loc = y_min(i) + 0.85*(y_max(i)-y_min(i));
            %text(ax1,x_loc,y_loc,fig_label(i),'interpreter','latex','fontsize',fontsize_ax);
        end
        % Now we add scoring rules
        ax1 = axes('units','inches'); axpos = [ 1.2 , 8.5 - numel(ID)*1.6 , 10 , 1.8 ]; set(ax1,'position',axpos);
        % Now add data
        i = 2; % homoscedastic forecast variance: s_kt = c*y_kt
        zz = 5; % weibull distribution
        % QS: green, LS: red, SS: blue, CRPS: yellow, ES: cyan
        plot(ax1,t_id,QS(t_id,zz,i),'color',green_color,'linewidth',2); hold on
        plot(ax1,t_id,LS(t_id,zz,i),'color',red_color,'linewidth',2);
        plot(ax1,t_id,SS(t_id,zz,i),'color',blue_color,'linewidth',2);
        plot(ax1,t_id,CRPS(t_id,zz,i),'color',yellow_color,'linewidth',2);
        plot(ax1,t_id,ES(t_id,zz,i),'color',cyan_color,'linewidth',2);
        % Adjust axis
        axis([t_id(1) t_id(end) y_min(nID+1) y_max(nID+1)]);
        % Adjust figure settings
        set(ax1,'tickdir','out','XMinorTick','on','YMinorTick','on','TickLength',[0.01 0.02]);
        set(ax1,'fontsize',16,'box','on');
        % Add figure number (label)
        x_loc = t_id(1) + 0.005*(t_id(nt)-t_id(1)); y_loc = y_min(nID+1) + 0.85*(y_max(nID+1)-y_min(nID+1));
        % text(ax1,x_loc,y_loc,fig_label(nID+1),'interpreter','latex','fontsize',fontsize_ax);
        % Make all of figure white
        set(gcf,'color','w');

    case 1 %% Only the predictive PDFS of the BMA model
        figure('unit','inches','PaperOrientation','portrait','position',[0.1 0.3 12 10.5]);
        ID = [ 6 7 8 9 10 ]; nID = numel(ID);
        fig_label = {'(a)','(b)','(c)','(d)','(e)'};
        y_min = -1/2*ones(1,nID); y_max = Ymax*ones(1,nID);
        cyan_color = [0,255,255]/255;
        t_id = 2620:2900; nt = numel(t_id);
        measdata_size = 4; blue_mean = [ 143 170 220]/255;
        for i = 1:nID
            zz = ID(i);
            ax1 = axes('units','inches'); axpos = [ 1.2 , 8.56 - (i-1)*2.0 , 10.5 , 1.9 ]; set(ax1,'position',axpos);
            % Now we add 95% BMA uncertainty
            Fill_Ranges(t_id,predQ(t_id,1,zz),predQ(t_id,6,zz),[0.94 0.94 0.94]); hold on;
            % Now we add 90% BMA uncertainty
            Fill_Ranges(t_id,predQ(t_id,2,zz),predQ(t_id,5,zz),[0.70 0.70 0.70]);
            % Now we add 50% BMA uncertainty
            Fill_Ranges(t_id,predQ(t_id,3,zz),predQ(t_id,4,zz),[0.5 0.5 0.45]);
            % %                     % Now we add 95% BMA uncertainty
            % %                     Fill_Ranges(t_id,predQ(t_id,1,zz),predQ(t_id,6,zz),[0.9 0.9 0.9]); hold on;
            % %                     % Now we add 90% BMA uncertainty
            % %                     Fill_Ranges(t_id,predQ(t_id,2,zz),predQ(t_id,5,zz),[0.65 0.65 0.65]);
            % %                     % Now we add 50% BMA uncertainty
            % %                     Fill_Ranges(t_id,predQ(t_id,3,zz),predQ(t_id,4,zz),[0.45 0.45 0.45]);
            % Now add data
            plot(ax1,t_id,Y(t_id),'ro','markerfacecolor','w','linewidth',1.25,'markersize',measdata_size);
            % And mean of BMA mixture
            plot(ax1,t_id,Mu_mix(t_id,zz),'color',blue_mean,'linewidth',1.25);
            % Adjust axis
            axis([t_id(1) t_id(end) y_min(i) y_max(i)]);
            % Adjust figure settings
            set(ax1,'tickdir','out','XMinorTick','on','YMinorTick','on','TickLength',[0.012 0.024],'box','off');
            if i <= nID - 1
                set(ax1,'xticklabel',[],'xtick',[]);
            end
            % set ylabel
            %ylabel(ax1,'${\rm Discharge,\;[mm/d]}$','Interpreter','latex','fontsize',20);
            set(ax1,'fontsize',fontsize_ax);
            % Add figure number (label)
            x_loc = t_id(1) + 0.005*(t_id(nt)-t_id(1)); y_loc = y_min(i) + 0.85*(y_max(i)-y_min(i));
            %text(ax1,x_loc,y_loc,fig_label(i),'interpreter','latex','fontsize',fontsize_ax);
        end
        % Adjust axis
        % axis([t_id(1) t_id(end) y_min(nID+1) y_max(nID+1)]);
        %set(ax1,'fontsize',16,'box','on');
        % Make all of figure white
        set(gcf,'color','w');

    case 2 % Figure of lognormal and traces scoring rules
        figure('unit','inches','PaperOrientation','portrait','position',[0.1 0.3 12 10.5]);
        y_min = [ -1/2*ones(1,nID) -YmaxSR ]; y_max = [ Ymax*ones(1,nID) YmaxSR ];
        cyan_color = [0,255,255]/255;
        t_id = 2620:2900; nt = numel(t_id);
        blue_mean = [ 143 170 220]/255;
        zz = ID(2); measdata_size = 4;
        ax1 = axes('units','inches'); axpos = [ 1.2 , 7.4 , 10.5 , 3 ]; set(ax1,'position',axpos);
        %                ax1 = axes('units','inches'); axpos = [ 1.2 , 8.4 , 10 , 2 ]; set(ax1,'position',axpos);
        % Now we add 95% BMA uncertainty
        Fill_Ranges(t_id,predQ(t_id,1,zz),predQ(t_id,6,zz),[0.94 0.94 0.94]); hold on;
        % Now we add 90% BMA uncertainty
        Fill_Ranges(t_id,predQ(t_id,2,zz),predQ(t_id,5,zz),[0.70 0.70 0.70]);
        % Now we add 50% BMA uncertainty
        Fill_Ranges(t_id,predQ(t_id,3,zz),predQ(t_id,4,zz),[0.5 0.5 0.45]);
        % Now add data
        plot(ax1,t_id,Y(t_id),'ro','markerfacecolor','w','linewidth',1.25,'markersize',measdata_size);
        % And mean of BMA mixture
        plot(ax1,t_id,Mu_mix(t_id,zz),'color',blue_mean,'linewidth',1.25);
        % Adjust axis
        axis([t_id(1) t_id(end) y_min(5) y_max(5)]);
        % Adjust figure settings
        set(ax1,'tickdir','out','XMinorTick','on','YMinorTick','on','TickLength',[0.012 0.024],'box','off');
        set(ax1,'xticklabel',[]);
        % set ylabel
        %ylabel(ax1,'${\rm Discharge,\;[mm/d]}$','Interpreter','latex','fontsize',20);
        set(ax1,'fontsize',fontsize_ax,'box','on');
        % Add figure number (label)
        %x_loc = t_id(1) + 0.005*(t_id(nt)-t_id(1)); y_loc = y_min(i) + 0.85*(y_max(i)-y_min(i));
        %text(ax1,x_loc,y_loc,fig_label(i),'interpreter','latex','fontsize',fontsize_ax);

        % Now add data
        i = 2; % homoscedastic forecast variance: option.VAR = '2'
        zz = 2; % lognormal distribution
        % Now we add scoring rules
        y_min = [-1 -6.5 0 -2.75 -13] ; y_max = [13 3 145 0.1 1];
        for uu = 1:5
            % QS: green, LS: red, SS: blue, CRPS: yellow, ES: cyan
            ax1 = axes('units','inches');
            axpos = [ 1.2 , 7.2 - uu * 1.2 , 10.5 , 1.1 ];
            %                    axpos = [ 1.2 , 8.2 - uu * 0.9 , 10 , 0.8 ];
            set(ax1,'position',axpos);
            switch uu
                case 1
                    plot(ax1,t_id,QS(t_id,zz,i),'color',green_color,'linewidth',2); hold on
                    set(ax1,'ytick',[0 6 12],'yticklabel',[0 6 12]);
                    ax1.YAxis.MinorTickValues = [2 4 8 10];
                case 2
                    plot(ax1,t_id,LS(t_id,zz,i),'color',red_color,'linewidth',2);
                    set(ax1,'ytick',[-6 -2 2 ],'yticklabel',[-6 -2 2]);
                    ax1.YAxis.MinorTickValues = [-4 0 ];
                case 3
                    plot(ax1,t_id,SS(t_id,zz,i),'color',blue_color,'linewidth',2);
                    set(ax1,'ytick',[20 70 120],'yticklabel',[20 70 120]);
                    ax1.YAxis.MinorTickValues = [45 95];
                case 4
                    plot(ax1,t_id,CRPS(t_id,zz,i),'color',yellow_color,'linewidth',2);
                    set(ax1,'ytick',[-2 -1 0],'yticklabel',[-2 -1 0]);
                    ax1.YAxis.MinorTickValues = [-2.5 -1.5 -0.5];
                case 5
                    plot(ax1,t_id,ES(t_id,zz,i),'color',cyan_color,'linewidth',2);
                    set(ax1,'ytick',[-12 -6 0],'yticklabel',[-12 -6 0]); %set(ax1,'ylim',[-14.8 ])
                    ax1.YAxis.MinorTickValues = [-10 -8 -4 -2];
            end
            % Adjust axis
            axis([t_id(1) t_id(end) y_min(uu) y_max(uu)]);
            % Adjust figure settings
            set(ax1,'tickdir','out','XMinorTick','on','YMinorTick','on','TickLength',[0.01 0.02]);
            set(ax1,'fontsize',16,'box','on');
            if uu < 5
                set(ax1,'xticklabel',[],'xtick',[]);
            end
            % Add figure number (label)
            %x_loc = t_id(1) + 0.005*(t_id(nt)-t_id(1)); y_loc = y_min(nID+1) + 0.85*(y_max(nID+1)-y_min(nID+1));
            % text(ax1,x_loc,y_loc,fig_label(nID+1),'interpreter','latex','fontsize',fontsize_ax);
        end
        % Make all of figure white
        set(gcf,'color','w');

    case 3
        figure('unit','inches','PaperOrientation','portrait','position',[0.1 0.3 19 10.5]);
        t_id = 1800:2300; Ymax = 25; nt = numel(t_id);
        y_min = [ 0 0 0 -12 ]; y_max = [ Ymax Ymax Ymax 12 ];
        for i = 1:3
            zz = ID(i);
            ax1 = axes('units','inches'); axpos = [ 1.2 , 8.2 - (i-1)*2.5 , 17 , 2.2 ]; set(ax1,'position',axpos);
            % Now we add 95% BMA uncertainty
            Fill_Ranges(t_id,predQ(t_id,1,zz),predQ(t_id,6,zz),[0.9 0.9 0.9]); hold on;
            % Now we add 90% BMA uncertainty
            Fill_Ranges(t_id,predQ(t_id,2,zz),predQ(t_id,5,zz),[0.7 0.7 0.7]);
            % Now we add 50% BMA uncertainty
            Fill_Ranges(t_id,predQ(t_id,3,zz),predQ(t_id,4,zz),[0.5 0.5 0.5]);
            % Now add data
            plot(ax1,t_id,Y(t_id),'rs','markerfacecolor','r','markersize',4);
            % Adjust axis
            axis([t_id(1) t_id(end) y_min(i) y_max(i)]);
            % Adjust figure settings
            set(ax1,'tickdir','out','XMinorTick','on','YMinorTick','on','TickLength',[0.01 0.02],'box','off');
            if i <= 3
                set(ax1,'xticklabel',[],'xtick',[]);
            end
            % set ylabel
            ylabel(ax1,'${\rm Discharge,\;[mm/d]}$','Interpreter','latex','fontsize',20);
            set(ax1,'fontsize',18);
            % Add figure number (label)
            x_loc = t_id(1) + 0.005*(t_id(nt)-t_id(1)); y_loc = y_min(i) + 0.9*(y_max(i)-y_min(i));
            text(ax1,x_loc,y_loc,fig_label(i),'interpreter','latex','fontsize',20);
        end
        % Now we add scoring rules
        ax1 = axes('units','inches'); axpos = [ 1.2 , 8.2 - 3*2.5 , 17 , 2.2 ]; set(ax1,'position',axpos);
        % Now add data
        i = 2; % heteroscedastic forecast variance: s_kt = c*y_kt
        zz = 5; % gamma distribution [0 102 255]: blue, [255 0 0]: red, [51 153 51]: green, [55 192 0]: yellow
        % QS: green, LS: red, SS: blue, CRPS: yellow
        plot(ax1,t_id,QS(t_id,zz,i),'color',green_color,'linewidth',2); hold on
        plot(ax1,t_id,LS(t_id,zz,i),'color',red_color,'linewidth',2);
        plot(ax1,t_id,SS(t_id,zz,i),'color',blue_color,'linewidth',2);
        plot(ax1,t_id,CRPS(t_id,zz,i),'color',yellow_color,'linewidth',2);
        plot(ax1,t_id,ES(t_id,zz,i),'color',orange_color,'linewidth',2);
        % Adjust axis
        axis([t_id(1) t_id(end) y_min(4) y_max(4)]);
        % Adjust figure settings
        set(ax1,'tickdir','out','XMinorTick','on','YMinorTick','on','TickLength',[0.01 0.02],'box','off');
        set(ax1,'fontsize',18);
        % Add figure number (label)
        x_loc = t_id(1) + 0.005*(t_id(nt)-t_id(1)); y_loc = y_min(4) + 0.9*(y_max(4)-y_min(4));
        text(ax1,x_loc,y_loc,fig_label(4),'interpreter','latex','fontsize',20);
        % Make all of figure white
        set(gcf,'color','w');
end