% ----------------------------------------------------------------------------------------- %
%                                                                                           %
% MM       MM   OOOOOOO   DDDDDDDD   EEEEEEEE  LL            AAA      VV       VV  GGGGGGGG %
% MMM      MM  OOOOOOOOO  DDDDDDDDD  EEEEEEEE  LL           AA AA     VV       VV  GG    GG %
% MMMM   MMMM  OO     OO  DD     DD  EE        LL           AA AA      VV     VV   GG    GG %
% MM MM MM MM  OO     OO  DD     DD  EEEEE     LL          AA   AA     VV     VV   GGGGGGGG %
% MM  MMM  MM  OO     OO  DD     DD  EEEEE     LL         AAAAAAAAA     VV   VV    GGGGGGGG %
% MM       MM  OO     OO  DD     DD  EE        LL         AA     AA      VV VV           GG %
% MM       MM  OOOOOOOOO  DDDDDDDDD  EEEEEEEE  LLLLLLLL  AA       AA     VV VV      GGGGGGG %
% MM       MM   OOOOOOO   DDDDDDDD   EEEEEEEE  LLLLLLLL  AA       AA      VVV      GGGGGGGG %
%                                                                                           %
% ----------------------------------------------------------------------------------------- %

%% CASE STUDY I: RAINFALL-RUNOFF TRANSFORMION - ENSEMBLE OF CALIBRATED WATERSHED MODELS
%% CHECK: J.A. VRUGT AND B.A. ROBINSON, WRR, 43, W01411, doi:10.1029/2005WR004838, 2007

%% CHECK https://www.authorea.com/users/597576/articles/632989-the-promise-of-diversity-distribution-based-hydrologic-model-evaluation-and-diagnostics

%% DEFINE MODEL AVERAGING METHOD
method = 'bma';             % 'ewa'/'bga'/'aica'/'bica'/'gra'/'bma'/'mma'/'mma-s'

%% FIXED SETTINGS
options.alpha = [0.95 0.75 0.5];   % prediction intervals of BMA model
options.print = 'no';              % print output (figures, tables) to screen
options.CPU = 'yes';

%% NOW LOAD DATA
S = load('discharge.txt');  % daily discharge forecasts (mm/day) of models and verifying data
idx_cal = 1:1:3000;         % start/end training period
idx_eval = 5001:7000;       % evaluation period
%% DEFINE ENSEMBLE AND VECTOR OF VERYFYING OBSERVATIONS
D = S(idx_cal,1:8); Y = S(idx_cal,9);
%% APPLY LINEAR BIAS CORRECTION TO ENSEMBLE ( UP TO USER )
[ D , a_LB , b_LB ] = Bias_correction ( D , Y );
%% NUMBER OF PARAMETERS OF EACH MODEL (ABC/GR4J/HYMOD/TOPMO/AWBM/NAM/HBV/SACSMA)
options.p = [ 3 4 5 8 8 9 9 13 ];   % ( only used for AICA, BICA, MMA, MMA-S)

%% BMA -> CONDITIONAL DISTRIBUTION NEEDS TO BE DEFINED
options.TAU = '2'; % Generalized normal - own tau for each member individually
PDF = {'normal','lognormal','gen_normal','gamma','weibull'};    % choice of conditional pdf
V = {'1','2'};                                                  % homoscedastic variance; group: '1' ; single: '2'
                                                                % heteroscedastic variance; group: '3' ; single: '4'
%% INITIALIZE VARIABLES/OUTPUT ARRAYS
nV = numel(V); nPDF = numel(PDF); nY = numel(Y);
[QS,LS,SS,CRPS,ES,Cv] = deal(nan(nY,nPDF,nV)); ct = 1; Table_9 = nan(13,nPDF*nV);
[mCv_anal,mCv_num,mRLBL_anal,mRLBL_num,KGE] = deal(nan(1,nPDF*nV)); Mu_mix = nan(nY,nPDF*nV);
predQ = nan(nY,2,nPDF*nV); nA = 2*numel(options.alpha);
m = 2e3;  % number of samples for computation CRPS and Energy Score
mm = 1e3; % number of samples to compute the norm of the density

%% Now do BMA method for all combinations of variances/conditional PDFs
for i = 1:nV
    % Group/sole homoscedastic variance 
    options.VAR = char(V(i));     
    for j = 1:nPDF
        % Define conditional pdf
        options.PDF = char(PDF(j));     
        % Run MODELAVG toolbox with two outputs
        [ beta , output ] = MODELAVG ( method , D , Y , options );
        % Compute exact mean and variance of BMA mixture
        [ Phi , mu_mix , var_mix ] = BMA_sample ( output.ML , D , m , options );
        % Determine lower and upper values of Phi
        lb = min(Phi,[],2); ub = max(Phi,[],2); count = 0;
        %% Compute scoring rules at each time
        for t = 1:nY 
            % Print progress
            if mod(t,floor(nY/25)) == 0
                if t > 1
                    fprintf(1, repmat('\b',1,count)); %delete line before
                    count = fprintf('Scoring rule calculation, %% done: %3.2f',100*(t/nY));
                end
            end
            yi = lb(t):(ub(t)-lb(t))/(mm-1):ub(t)+1e-6;
            pdf_yi = ksdensity(Phi(t,1:m),yi,'function','pdf');
            % Compute norm of BMA density
            pdf_norm = norm(pdf_yi/sum(pdf_yi),2);
            % Compute different scoring rules
            QS(t,j,i) = 2*output.pdf_Y(t) - pdf_norm^2;
            LS(t,j,i) = log2(output.pdf_Y(t));
            SS(t,j,i) = output.pdf_Y(t) / pdf_norm;
            CRPS(t,j,i) = CRP_score(Phi(t,1:m),Y(t));
            ES(t,j,i) = energy_score(Phi(t,1:m),Y(t),2);
            % Informal metrics - numerical estimate of Cv (unreliable!!)
            Cv(t,j,i) = std(Phi(t,1:m))/mean(Phi(t,1:m));
        end
        % Store prediction quantiles for each alpha value of options.alpha
        predQ(1:nY,1:nA,ct) = output.pred;
        % Compute exact reliability for BMA model
        mRLBL_anal(ct) = BMA_rlbl(output.cdf_Y);
        % Compute reliability from p-values [Renard et al., 2011]
        p_val = p_values(Phi,Y); mRLBL_num(ct) = rlbl(p_val); 
        % Get mean values of scores
        mQS = mean(QS(1:nY,j,i)); mLS = mean(LS(1:nY,j,i)); mSS = mean(SS(1:nY,j,i));
        mCRPS = mean(CRPS(1:nY,j,i)); mES = mean(ES(1:nY,j,i));
        id4 = find(~isnan(Cv(1:nY,j,i))); mCv_num(ct) = mean(Cv(id4,j,i));
        % Exact estimate of mean of CV (CVexact = sqrt(var_mix)./mu_mix)
        mCv_anal(ct) = mean(sqrt(var_mix)./mu_mix);
        % Store mean prediction of BMA model
        Mu_mix(1:nY,ct) = mu_mix;
        % Compute KGE efficiency of weighted average (= mean) BMA forecast
        KGE(ct) = compKGE(Y,mu_mix);
        % Now store results
        Table_9(:,ct) = [ mQS mLS mSS mCRPS mES , mRLBL_anal(ct) , ...
            mCv_anal(ct) output.coverage(end)/100 ...
            output.spread(end) , output.loglik output.RMSE output.R2 ...
            KGE(ct) ]';
        % Update counter
        ct = ct + 1;
    end
end

%% NOW DEFINE EVALUATION DATA
% D_eval = S(idx_eval,1:8); Y_eval = S(idx_eval,9);
% Can evaluate and print performance evaluation period using
% val = MODELAVG_eval ( method , D_eval , Y_eval , options , beta , a_LB , b_LB , output );