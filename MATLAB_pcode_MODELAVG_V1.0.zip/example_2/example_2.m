% ----------------------------------------------------------------------------------------- %
%                                                                                           %
% MM       MM   OOOOOOO   DDDDDDDD   EEEEEEEE  LL            AAA      VV       VV  GGGGGGGG %
% MMM      MM  OOOOOOOOO  DDDDDDDDD  EEEEEEEE  LL           AA AA     VV       VV  GG    GG %
% MMMM   MMMM  OO     OO  DD     DD  EE        LL           AA AA      VV     VV   GG    GG %
% MM MM MM MM  OO     OO  DD     DD  EEEEE     LL          AA   AA     VV     VV   GGGGGGGG %
% MM  MMM  MM  OO     OO  DD     DD  EEEEE     LL         AAAAAAAAA     VV   VV    GGGGGGGG %
% MM       MM  OO     OO  DD     DD  EE        LL         AA     AA      VV VV           GG %
% MM       MM  OOOOOOOOO  DDDDDDDDD  EEEEEEEE  LLLLLLLL  AA       AA     VV VV      GGGGGGG %
% MM       MM   OOOOOOO   DDDDDDDD   EEEEEEEE  LLLLLLLL  AA       AA      VVV      GGGGGGGG %
%                                                                                           %
% ----------------------------------------------------------------------------------------- %

%% CASE STUDY II: 48-FORECASTS OF SEA SURFACE TEMPERATURE
%% CHECK: A.E. RAFTERY ET AL., MWR, 133, pp. 1155-1174, 2005.

%% DEFINE MODEL AVERAGING METHOD
method = 'bma';             % 'ewa'/'bga'/'aica'/'bica'/'gra'/'bma'/'mma'/'mma-s'

%% BMA -> CONDITIONAL DISTRIBUTION NEEDS TO BE DEFINED
options.PDF = 'normal';     % pdf predictor: normal/gamma/gen_normal
options.VAR = '2';          % individual constant variance
options.alpha = 0.95;       % prediction intervals of BMA model (0.90/0.95/0.99)
options.print = 'yes';      % print output (figures, tables) to screen

%% NOW LOAD DATA
T = load('temp.txt');       % 48-hour forecasts temperature (Kelvin) and verifying data 

%% DEFINE ENSEMBLE AND VECTOR OF VERYFYING OBSERVATIONS ( APRIL 16 TO JUNE 9, 2000 )
idx = find(T(:,1) == 2000 & T(:,2) == 4 & T(:,3) == 16); start_idx = idx(1);
idx = find(T(:,1) == 2000 & T(:,2) == 6 & T(:,3) == 9); end_idx = idx(1);
D = T(start_idx:end_idx,5:9); Y = T(start_idx:end_idx,4);

%% APPLY LINEAR BIAS CORRECTION TO ENSEMBLE ( UP TO USER )
[ D , a , b ] = Bias_correction ( D , Y );

% Run MODELAVG toolbox with two outputs
[ beta , output ] = MODELAVG ( method , D , Y , options ); 